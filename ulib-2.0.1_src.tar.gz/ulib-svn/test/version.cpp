#include <stdio.h>
#include <ulib/ulib_ver.h>

int main()
{
	printf("%s\n", ulib_version());

	printf("passed\n");

	return 0;
}
